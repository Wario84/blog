Welcome to the material of IDS
